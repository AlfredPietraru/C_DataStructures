README

Introducere: tema mi-a luat 2 saptamani in care am lucrat constant, pana sa ma apuc 
de ea pur si simplu nu stiam ce sunt listele, totusi mi-a placut deoarece se leaga 
putin de matematica si interpretarea datelor, plus ca a fost o metoda buna sa exersez
aceste notiuni pentru a le intelege. 
In main primele linii de cod sunt general valabile pentru toate task-urile, este
citit numarul de perechi, iar functia "create", primeste ca parametru header-ul listei
si numarul de elemente si creeaza lista, "argc" reprezinta numarul de argumente introduse
in lista , "argv" este un vector de siruri de caractere care reprezinta comenzile in sine.
Cu ajutorul functiei "strcmp" si a catorva if-uri vad ce argumente sunt introduse in 
linia de comanda.

Task --e1
Functia "average_5" calculeaza media a 5 elemente, "standard_deviation" calculeaza deviatia
standard, rezultatul ambelor functii un numar de format double. Functia "go_five" primeste ca
parametru un nod din lista, si imi spune daca exista 4 elemente in fata acestuia diferite de 
NULL,practic, imi spune daca pot forma perechi de cate 5 pe baza caruia pot calcula media si 
deviatia standard, aceasta are ca rezultat 0 sau 1, 1 daca se poate forma grupe de 5, iar 0
daca nu. Functia "is_range" primeste ca parametru nodul si verifaca daca valoarea acestuia de
tip double se incadreaza in intervalul dat prin calculul functiei "average_5" si "standard_deviation".
Daca elementul nu respecta intervalul este eliminat.

Task --e2
Se apeleaza din nou functia "go_five", iar argumentul primit  va fi head-ul unei liste temporare 
de 5 elemente. Folosim functia "sort_list" care va pune in ordine crescatoare valorile double are 
fiecarui nod din lista, dupa este extrasa valoarea mediana si timestamp-ul corespondent. Prin 
intermediul functiei "append" care priemste ca si parametru "final_head", timestamp-ul si 
valoarea double a elementului median, si este creat nodul intr-o noua lista cu header-ul "final_head". 
Lista nou formata este afisata iar numaruldePerechi este modificat in functie de cate valori 
au fost afisate din lista "final_head".

Task --e3
Functia create_five primeste ca parametru un nod din lista si un pointer catre o structura numita
"head_five" care va deveni header-ul. Aceasta copie 5 elemente lista principala in una auxiliara.
Ulterior aceasta este folosita pentru  a calcula media elementelor double din interiorul ei 
iar functia append adauga la "final_head" , timestamp-ul mediu si rezultatul functiei 
"average_5" cu elementele din lista "head_five".

Task --u
Functia turn_node se apeleaza incepand cu al doilea element, modificand fiecare in parte timestamp
si value din fiecare nod al listei.

Task --c
Personal task-ul acesta mi s-a parut cel mai greu din cauza explicatiilor insuficiente, nici pana 
acum nu imi este clar de ce in calculul lui f, se ia right ca plecand de la ultima valoare,
am avut noroc sa obtin rezultatul deoarece am luat separat functiile de liste, functia f,w si C 
si am interschimbat valorile pana a dat raspunsul potrivit. Mereu obtineam valori foarte apropiate..
de genul 2.46 sau 2.38 dar nu 2.42 cat trebuia.
Cand m-am apucat de rezolvat, am facut prima data functia C, dupa w si dupa f si le-am verificat separat
pe fiecare in parte. Aveam un while care ma trecea prin fiecare element al listei si verificam ca diferenta
dintre elementul curent si precedent sa fie mai mica de 1000. In caz contrar creeam 2 liste care aveau ca
left_head si right_head si acolo memoram cu 3 valori inainte de temp si in right_head urmatoarele 3 valori.
Aflam timestamp-ul adunand cate 200 la fiecare valoare, iar elementul value din fiecare structura il 
calculam cu ajutorul functiei f. Functia add_node primeste ca parametru header-ul listei, timestamp-ul si
rezultatul lui f si creeaza nodul. Prin apelari succesive sunt adaugate toate elementele necesare direct la
lista initiala iar la final este afisata si eliberata memoria.

Task --st
Cand m-am apucat de task-ul acesta nu stiam cum as putea obtine numarul care este dat ca si argument,
asa ca in primul rand am considerat important sa fiu sigur ca indiferent de delta, comanda primita este 
"--st". Folosind strstr, daca acest sir se regaseste undeva in argument rezultatul este un pointer catre acesta
atata timp cat rezultatul functie strstr este diferint de NULL se pot executa restul instructiunilor din conditia
if. Dupa am aflat delta folosind strtol. In momentul in care am aflat delta, lucrurile s-au simplificat,
pentru a-mi usura cautarea, am aflat minimul si maximul elementului value din lista si am ordonat crescator 
elementele value din lista, interschimband doar valorile fara sa modific nodurile listei in vreun fel.
Ultimul if are rol de a-mi asigura corectitudinea la afisare astfel incat sa primesc punctajul pe task-uri.
Deoarece st este singurul task in care nu se cere afisarea a efectiva a listei, ci doar a unor intervale si valori.

In concluzie: chiar mi-a placut sa rezolv tema...s-a legat de matematica si statisca, si mi-a oferit un oarecare
boost de incredere in legatura cu capacitatea mea de a trece cu bine prin aceasta facultate.



