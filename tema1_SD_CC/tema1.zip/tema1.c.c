#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
// definesc tipul de date+functiile care opereaza cu noduri
struct data
{
    int timestamp;
    double value;
};

struct node
{
    struct data x;
    struct node *next;
    struct node *prev;
};

void delnode(struct node *pos)
{
    struct node *go_die;
    go_die = pos;
    pos->prev->next = pos->next;
    pos->next->prev = pos->prev;
    free(go_die);
}

void create(struct node **head, int n)
{
    int timestamp;
    double value;
    struct node *aux = NULL;
    int i;
    for (i = 0; i < n; i++)
    {
        scanf("%d%lf", &timestamp, &value);
        struct node *new;
        new = malloc(sizeof(*new));
        new->x.timestamp = timestamp;
        new->x.value = value;
        new->next = NULL;
        new->prev = aux;
        if (*head == NULL)
        {
            *head = new;
        }
        else
        {
            aux->next = new;
        }
        aux = new;
    }
}

void add_node(struct node *pos,int timestamp,double value)
{
    struct node *new_node;
    new_node=(struct node*)malloc(sizeof(struct node));
    new_node->x.timestamp=timestamp;
    new_node->x.value=value;
    new_node->next=pos->next;
    pos->next->prev=new_node;
    new_node->prev=pos;
    pos->next=new_node;

}

void display(struct node *head)
{
    struct node *p = head;
    while (p != NULL)
    {
        printf("%d %0.2lf\n", p->x.timestamp, p->x.value);
        p = p->next;
    }
}

void free_all(struct node *head)
{
    struct node *last = head;
    while (last->next)
    {
        struct node *go_die = last;
        last = last->next;
        free(go_die);
    }
    if (last)
    {
        free(last);
    }
}


// aici incep functiile de la task-ul 2.1, incepand cu media a 5 elemente

double average_5(struct node *pos)
{
    double s = 0;
    int k = 0;
    pos = pos->prev->prev;
    while (k < 5)
    {
        s = s + pos->x.value;
        pos = pos->next;
        k++;
    }
    s = s / 5;
    return s;
}
// calculul deviatiei a 5 elemente,se pleaca de la pozitia pos, se merge 2 pozitii in spate si 2 in fata
double standard_deviation(struct node *pos)
{
    int i = 0;
    double averagee = average_5(pos);
    double std_dev = 0;
    pos = pos->prev->prev;
    while (pos != NULL && i < 5)
    {
        std_dev = std_dev + (pos->x.value - averagee) * (pos->x.value - averagee);
        pos = pos->next;
        i++;
    }
    std_dev = std_dev / 5;
    std_dev = sqrt(std_dev);

    return std_dev;
}
// daca elementul respectiv nu se afla in interval dat de medie si variatie, rezultatul va fi 1,
int go_five(struct node *pos)
{
    int k = 0;
    while (pos != NULL && k < 5)
    {
        pos = pos->next;
        k = k + 1;
    }
    if (k != 5)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

int is_range(struct node *pos)
{
    double averagee = average_5(pos);
    double std_dev = standard_deviation(pos);
    if (averagee - std_dev < pos->x.value && pos->x.value < averagee + std_dev)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int compare(struct node *first, struct node *second)
{
    if (first->x.timestamp != second->x.timestamp)
    {
        return 0;
    }
    if (first->x.value != second->x.value)
    {
        return 0;
    }
    return 1;
}

// aici se termina functiile de la task-ul 2.1

// functii task 2.2.1

void inversare(struct node **small, struct node **big)
{
    double aux;
    if ((*small)->x.value > (*big)->x.value)
    {
        aux = (*small)->x.value;
        (*small)->x.value = (*big)->x.value;
        (*big)->x.value = aux;
    }
}

void create_five(struct node *head, struct node **new_head)
{
    struct node *aux1 = NULL;
    int i;
    for (i = 0; i < 5; i++)
    {
        struct node *new1;
        new1 = malloc(sizeof(struct node));
        new1->x.timestamp = head->x.timestamp;
        new1->x.value = head->x.value;
        new1->next = NULL;
        new1->prev = aux1;
        if (*new_head == NULL)
        {
            *new_head = new1;
        }
        else
        {
            aux1->next = new1;
        }
        aux1 = new1;
        head = head->next;
    }
}

void sort_list(struct node **new_head)
{
    struct node *temp1 = NULL;
    struct node *temp2 = NULL;
    for (temp1 = *new_head; temp1->next != NULL; temp1 = temp1->next)
    {
        for (temp2 = temp1->next; temp2 != NULL; temp2 = temp2->next)
        {
            inversare(&temp1, &temp2);
        }
    }
}

void append(struct node **head_ref, int timestamp, double value)
{
    struct node *new_node = (struct node *)malloc(sizeof(struct node));

    struct node *last = *head_ref;

    new_node->x.timestamp = timestamp;
    new_node->x.value = value;

    new_node->next = NULL;

    if (*head_ref == NULL)
    {
        new_node->prev = NULL;
        *head_ref = new_node;
        return;
    }
    while (last->next != NULL)
    {
        last = last->next;
    }

    last->next = new_node;
    new_node->prev = last;
}

// aici se termina functiile de la task-ul 2.2.1

// functii task 2.3

void turn_node(struct node **pos)
{

    if ((*pos)->x.timestamp - (*pos)->prev->x.timestamp >= 100 && (*pos)->x.timestamp - (*pos)->prev->x.timestamp <= 1000)
    {
        (*pos)->x.timestamp = (double)((*pos)->x.timestamp + (*pos)->prev->x.timestamp) / 2;
        (*pos)->x.value = (double)((*pos)->x.value + (*pos)->prev->x.value) / 2;
    }
}

// aici se termina functiile pentru task 2.3

// functii task 2.4

double w(int i, int k)
{
    double numerator = (double)i / (k - 1) * i / (k - 1) * 0.9;
    numerator = numerator + 0.1;
    double denominator = 0;
    int j;
    for (j = 0; j < k; j++)
    {
        double add = (double)j / (k - 1) * j / (k - 1);

        denominator = denominator + add * 0.9 + 0.1;
    }
    return numerator / denominator;
}

double C(int timestamp,int left,int right)
{
    double res=(double)(timestamp-left)/(right-left);
    return res;
}

double f(struct node *left_head, struct node *right_head, int timestamp)
{
   double C_scale=C(timestamp, left_head->x.timestamp, right_head->x.timestamp);
    int k = 3;
    int i; 
    double res1=0,res2= 0;
    left_head=left_head->next->next;
    right_head=right_head->next->next;
    for (i = 0; i <k; i++)
    {   
        res1 = res1+(1 - C_scale) * left_head->x.value * w(i, k);
        res2 = res2+C_scale * right_head->x.value * w(i, k);
        left_head = left_head->prev;
        right_head = right_head->prev;
       
    }
    return res1+res2;
}
// aici se termina functiile pentru task 2.4

//functii task --st<delta>


//aici se termina functiile pentru task --st<delta>
int main(int argc, char *argv[])
{
    // bucata de cod general valabila pentru toate task-urile
    int numarPerechi,ok_s=0;
    int numar_valori_e2 = 0, numar_valori_e3 = 0; // pt task--e2 si --e3
    scanf("%d", &numarPerechi);
    struct node *head = NULL;
    struct node *head_find = NULL;
    create(&head, numarPerechi);
    int i;
    for (i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "--e1") == 0)
        {
            // task 2.1
            struct node *temp = NULL;
            temp = head->next->next;

            while (temp->next->next != NULL)
            {

                if (is_range(temp) == 0)
                {
                    temp = temp->next;
                    append(&head_find, temp->prev->x.timestamp, temp->prev->x.value);
                }
                else
                {
                    temp = temp->next;
                }
            }
            struct node *x;
            struct node *y;

            for (x = head->next; x->next != NULL; x = x->next)
            {
                for (y = head_find; y != NULL; y = y->next)
                {
                    if (compare(x->prev, y) == 1)
                    {
                        delnode(x->prev);
                        numarPerechi = numarPerechi - 1;
                    }
                }
            }

            free_all(head_find);

            // end_task2.1
        }
        if (strcmp(argv[i], "--e2") == 0)
        { 

            // start task 2.2.1

            struct node *temp_e2;
            temp_e2 = head;
            struct node *final_head = NULL;
            while (go_five(temp_e2) == 1)
            {
                struct node *head_five = NULL;
                create_five(temp_e2, &head_five);
                sort_list(&head_five);
                int timestamp = head_five->next->next->x.timestamp;
                double value = head_five->next->next->x.value;
                append(&final_head, timestamp, value);
                temp_e2 = temp_e2->next;
                numar_valori_e2 = numar_valori_e2 + 1;
                free_all(head_five);
            }
            numarPerechi = numar_valori_e2;
            free_all(head);
            head = final_head;

            // end task 2.2.1
        }
        if (strcmp(argv[i], "--e3") == 0)
        { 
            // start task 2.2.2
            struct node *temp_e3 = NULL;
            temp_e3 = head;
            struct node *final_head = NULL;
            while (go_five(temp_e3) == 1)
            {
                struct node *head_five = NULL;
                create_five(temp_e3, &head_five);
                int timestamp = head_five->next->next->x.timestamp;
                append(&final_head, timestamp, average_5(head_five->next->next));
                temp_e3 = temp_e3->next;
                numar_valori_e3 = numar_valori_e3 + 1;
                free_all(head_five);
            }
            numarPerechi = numar_valori_e3;
            free_all(head);
            head = final_head;

            // end task 2.2.2
        }
        if (strcmp(argv[i], "--u") == 0)
        {
            // start task 2.3
            struct node *temp = NULL;
            temp = head->next;
            struct node *x=NULL;
            for(x = temp; x != NULL; x = x->next)
            {
                turn_node(&x);
            }
            // end task 2.3
        }
        if (strcmp(argv[i], "--c") == 0)
        {
            struct node *temp_c;
            temp_c = head;
            temp_c = temp_c->next;
            
            while (temp_c != NULL)
            {
                if (temp_c->x.timestamp - temp_c->prev->x.timestamp > 1000)
                {
                    struct node *left_head = NULL;
                    struct node *right_head = NULL;
                    struct node *create_left = NULL;
                    create_left = temp_c->prev;
                    struct node *create_right = NULL;
                    create_right = temp_c;
                    int i;
                    for (i = 0; i < 3; i++)
                    {
                        
                        append(&left_head, create_left->x.timestamp, create_left->x.value);
                        append(&right_head, create_right->x.timestamp, create_right->x.value);
                        create_left = create_left->prev;
                        create_right = create_right->next;
                    }
                    int timestamp = temp_c->prev->x.timestamp;
                    while (timestamp+200 < temp_c->x.timestamp)
                    {  
                        timestamp = timestamp + 200;
                        add_node(temp_c->prev,timestamp,f(left_head, right_head, timestamp));
                        numarPerechi = numarPerechi + 1;
                    
                    }
                    temp_c = temp_c->next;
                   
                    free_all(left_head);
                    free_all(right_head);

                }
                else
                {
                    temp_c = temp_c->next;
                }
            }
        }
        if(strstr(argv[i],"--st"))
        {    ok_s=1;
            char *p;
            p=strstr(argv[i],"--st");
            p=p+4;
           int delta;
            char *ptr;
            delta = strtol(p, &ptr, 10);
            struct node *temp_st=NULL;
            temp_st=head;
            double min_value=0;
            double max_value=0;
            int upper=delta;
            int appear_number=0;
            struct node *last=NULL;
            last=head;
            while(last->next!=NULL)
            {
                if(last->x.value<min_value)
                {
                    min_value=last->x.value;
                }
                if(last->x.value>max_value)
                {
                    max_value=last->x.value;
                }
                last=last->next;
            }
            while(upper>min_value)
            {
                upper=upper-delta;
            }
            sort_list(&head);
            while(upper<=(int)max_value)
            {   appear_number=0;
                while(upper<=temp_st->x.value && temp_st->x.value<upper+delta)
                {
                    appear_number=appear_number+1;
                    if(temp_st->next==NULL)
                    {
                 
                        break;
                    }
                    else
                    {
                    temp_st=temp_st->next;
                    }
                }
                if(appear_number!=0)
                {
                printf("[%d, %d] %d\n",upper,upper+delta,appear_number);
                }
                 upper=upper+delta;
            }
        }
    }
    if(ok_s==0)
    {
    printf("%d\n", numarPerechi);
    display(head);
    }
    free_all(head);
}